install.packages("ggplot2")
install.packages("dplyr")
install.packages("tidyr")
library(ggplot2)
library(dplyr)
library(tidyr)
# Read in the data
df <- read.csv("C:/Users/Dell/Downloads/netflix_data.csv")
# Check for missing values
print(colSums(is.na(df)))
# Process genres
genre_series <- df %>%
  separate_rows(listed_in, sep = ",") %>%
  mutate(listed_in = trimws(listed_in)) %>%
  count(listed_in, sort = TRUE)
  # Create and display the plot
ggplot(genre_series, aes(x = reorder(listed_in, n), y = n)) + 
  geom_bar(stat = "identity") +
  ggtitle("Most Watched Genres") +
  xlab("Genres") + 
  ylab("Number of Shows/Movies") +
  theme(axis.text.x = element_text(angle = 40, hjust = 1)) +
  coord_flip()
  




